week6
